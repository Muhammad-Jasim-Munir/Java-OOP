// PostDAO.java
package dao;

import db.DBConnection;
import model.Post;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PostDAO {

    public static boolean addPost(Post post, Connection conn) {
        String sql = "INSERT INTO posts (user_id, content, created_at) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, post.getUserId());
            stmt.setString(2, post.getContent());
            stmt.setTimestamp(3, post.getCreatedAt());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error adding post: " + e.getMessage());
            return false;
        }
    }

    public static boolean addPost(Post post) {
        try (Connection conn = DBConnection.getConnection()) {
            return addPost(post, conn);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Post> getAllPosts(Connection conn) {
        List<Post> posts = new ArrayList<>();
        String sql = "SELECT * FROM posts ORDER BY created_at DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Post post = new Post(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("content"),
                        rs.getTimestamp("created_at")
                );
                posts.add(post);
            }
        } catch (SQLException e) {
            System.err.println("Error getting posts: " + e.getMessage());
        }

        return posts;
    }

    public static List<Post> getPostsByUser(int userId, Connection conn) {
        List<Post> posts = new ArrayList<>();
        String sql = "SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Post post = new Post(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("content"),
                        rs.getTimestamp("created_at")
                );
                posts.add(post);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching user posts: " + e.getMessage());
        }

        return posts;
    }
}
