package dao;

import model.Like;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LikeDAO {

    // Add a like to a post
    public static boolean addLike(Like like, Connection conn) {
        String sql = "INSERT INTO likes (post_id, user_id) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, like.getPostId());
            stmt.setInt(2, like.getUserId());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error in addLike: " + e.getMessage());
            return false;
        }
    }

    // Remove a like (unlike)
    public static boolean removeLike(int postId, int userId, Connection conn) {
        String sql = "DELETE FROM likes WHERE post_id = ? AND user_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, postId);
            stmt.setInt(2, userId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error in removeLike: " + e.getMessage());
            return false;
        }
    }

    // Get total number of likes for a post
    public static int getLikeCount(int postId, Connection conn) {
        String sql = "SELECT COUNT(*) FROM likes WHERE post_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, postId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Error in getLikeCount: " + e.getMessage());
        }
        return 0;
    }

    // Check if user already liked a post
    public static boolean isPostLikedByUser(int postId, int userId, Connection conn) {
        String sql = "SELECT id FROM likes WHERE post_id = ? AND user_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, postId);
            stmt.setInt(2, userId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("Error in isPostLikedByUser: " + e.getMessage());
            return false;
        }
    }
}
