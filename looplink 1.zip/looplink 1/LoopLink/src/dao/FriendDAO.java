package dao;

import model.Friend;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FriendDAO {

    public static boolean sendFriendRequest(int senderId, int receiverId, Connection conn) {
        String sql = "INSERT INTO friends (sender_id, receiver_id, status, created_at) VALUES (?, ?, 'pending', NOW())";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, senderId);
            stmt.setInt(2, receiverId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error sending friend request: " + e.getMessage());
            return false;
        }
    }

    public static boolean acceptFriendRequest(int senderId, int receiverId, Connection conn) {
        String sql = "UPDATE friends SET status = 'accepted' WHERE sender_id = ? AND receiver_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, senderId);
            stmt.setInt(2, receiverId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error accepting friend request: " + e.getMessage());
            return false;
        }
    }

    public static List<Friend> getFriendRequests(int userId, Connection conn) {
        List<Friend> list = new ArrayList<>();
        String sql = "SELECT * FROM friends WHERE receiver_id = ? AND status = 'pending'";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new Friend(
                        rs.getInt("id"),
                        rs.getInt("sender_id"),
                        rs.getInt("receiver_id"),
                        rs.getString("status"),
                        rs.getTimestamp("created_at")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting friend requests: " + e.getMessage());
        }
        return list;
    }

    public static List<Friend> getSuggestions(int userId, Connection conn) {
        List<Friend> suggestions = new ArrayList<>();
        String sql = """
            SELECT id, ? AS sender_id, id AS receiver_id, 'suggested' AS status, NOW() AS created_at
            FROM users
            WHERE id != ?
              AND id NOT IN (
                SELECT receiver_id FROM friends WHERE sender_id = ?
                UNION
                SELECT sender_id FROM friends WHERE receiver_id = ?
              )
        """;
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, userId);
            stmt.setInt(3, userId);
            stmt.setInt(4, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                suggestions.add(new Friend(
                        rs.getInt("id"),
                        rs.getInt("sender_id"),
                        rs.getInt("receiver_id"),
                        rs.getString("status"),
                        rs.getTimestamp("created_at")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error getting suggestions: " + e.getMessage());
        }
        return suggestions;
    }
}
