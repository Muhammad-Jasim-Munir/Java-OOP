// LoginFrame.java
package gui;

import dao.UserDAO;
import model.User;
import util.Session;
import db.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.util.Optional;

public class LoginFrame extends JFrame {
    public LoginFrame() {
        setTitle("LoopLink - Login");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Color bgColor = new Color(30, 30, 46);
        Color inputBg = new Color(42, 42, 62);
        Color accent = new Color(0, 153, 255);
        Color secondaryAccent = new Color(100, 100, 255);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(bgColor);

        JLabel heading = new JLabel("LoopLink Login", SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 26));
        heading.setForeground(Color.WHITE);
        heading.setBorder(BorderFactory.createEmptyBorder(30, 0, 10, 0));
        panel.add(heading, BorderLayout.NORTH);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBackground(bgColor);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 60, 20, 60));

        JTextField emailField = new JTextField();
        emailField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        emailField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        emailField.setBackground(inputBg);
        emailField.setForeground(Color.WHITE);
        emailField.setCaretColor(Color.WHITE);
        emailField.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(accent), "Email", 0, 0, null, Color.WHITE));

        JPasswordField passField = new JPasswordField();
        passField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        passField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        passField.setBackground(inputBg);
        passField.setForeground(Color.WHITE);
        passField.setCaretColor(Color.WHITE);
        passField.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(accent), "Password", 0, 0, null, Color.WHITE));

        JButton loginBtn = new JButton("Login");
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        loginBtn.setBackground(accent);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.setOpaque(true);
        loginBtn.setBorderPainted(false);
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginBtn.setPreferredSize(new Dimension(120, 40));

        JButton registerBtn = new JButton("Register");
        registerBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        registerBtn.setBackground(secondaryAccent);
        registerBtn.setForeground(Color.WHITE);
        registerBtn.setFocusPainted(false);
        registerBtn.setOpaque(true);
        registerBtn.setBorderPainted(false);
        registerBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        registerBtn.setPreferredSize(new Dimension(120, 40));

        loginBtn.addActionListener(e -> {
            String email = emailField.getText().trim();
            String password = String.valueOf(passField.getPassword());

            if (email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter both email and password.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try (Connection conn = DBConnection.getConnection()) {
                Optional<User> optionalUser = UserDAO.login(email, password, conn);

                if (optionalUser.isPresent()) {
                    User user = optionalUser.get();
                    Session.setCurrentUser(user);
                    JOptionPane.showMessageDialog(this, "Login successful!");
                    dispose();
                    new HomeFeedFrame();
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid email or password.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Login failed!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        registerBtn.addActionListener(e -> {
            dispose();
            new RegisterFrame(); // Make sure RegisterFrame exists
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setBackground(bgColor);
        buttonPanel.add(loginBtn);
        buttonPanel.add(registerBtn);

        formPanel.add(emailField);
        formPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        formPanel.add(passField);
        formPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        formPanel.add(buttonPanel);

        panel.add(formPanel, BorderLayout.CENTER);
        setContentPane(panel);
        setVisible(true);
    }
}
