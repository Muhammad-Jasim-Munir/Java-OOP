package gui;
import dao.PostDAO;
import model.Post;
import util.Session;
import db.DBConnection;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;

public class CreatePostFrame extends JFrame {
    public CreatePostFrame() {
        setTitle("Create New Post");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Color scheme
        Color bgColor = new Color(30, 30, 46);
        Color inputBg = new Color(42, 42, 62);
        Color accent = new Color(0, 153, 255);
        Color textColor = Color.WHITE;

        JPanel panel = new JPanel();
        panel.setBackground(bgColor);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("What's on your mind?");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(textColor);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);

        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JTextArea postArea = new JTextArea();
        postArea.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        postArea.setLineWrap(true);
        postArea.setWrapStyleWord(true);
        postArea.setBackground(inputBg);
        postArea.setForeground(textColor);
        postArea.setCaretColor(textColor);
        postArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(accent),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        JScrollPane scrollPane = new JScrollPane(postArea);
        scrollPane.setPreferredSize(new Dimension(350, 180));
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        panel.add(scrollPane);

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton postBtn = new JButton("Post");
        postBtn.setBackground(accent);
        postBtn.setForeground(Color.WHITE);
        postBtn.setFocusPainted(false);
        postBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        postBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        postBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        postBtn.setPreferredSize(new Dimension(120, 40));
        postBtn.setMaximumSize(new Dimension(150, 45));
        postBtn.setMinimumSize(new Dimension(100, 40));
        postBtn.setOpaque(true);
        postBtn.setBorderPainted(false);

        postBtn.addActionListener(e -> {
            String content = postArea.getText().trim();
            if (content.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Post content cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try (Connection conn = DBConnection.getConnection()) {
                Post post = new Post(Session.getCurrentUser().getId(), content);
                PostDAO.addPost(post, conn);
                JOptionPane.showMessageDialog(this, "Post shared successfully!");
                dispose();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Failed to post.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(postBtn);
        add(panel);
        setVisible(true);
    }
}
