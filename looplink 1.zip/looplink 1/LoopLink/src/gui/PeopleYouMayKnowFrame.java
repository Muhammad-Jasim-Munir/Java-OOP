package gui;

import dao.FriendDAO;
import model.Friend;
import util.Session;
import db.DBConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.util.List;

public class PeopleYouMayKnowFrame extends JFrame {
    public PeopleYouMayKnowFrame() {
        setTitle("People You May Know");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Dark theme colors
        Color bgColor = new Color(30, 30, 46);
        Color cardColor = new Color(42, 42, 62);
        Color textColor = Color.WHITE;
        Color accentGreen = new Color(40, 180, 99);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(bgColor);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel heading = new JLabel("People You May Know");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 20));
        heading.setForeground(textColor);
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(heading);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        try (Connection conn = DBConnection.getConnection()) {
            int userId = Session.getCurrentUser().getId();
            List<Friend> suggestions = FriendDAO.getSuggestions(userId, conn);

            if (suggestions.isEmpty()) {
                JLabel empty = new JLabel("No suggestions at this time.");
                empty.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                empty.setForeground(textColor);
                empty.setAlignmentX(Component.CENTER_ALIGNMENT);
                mainPanel.add(empty);
            } else {
                for (Friend f : suggestions) {
                    JPanel card = new JPanel(new BorderLayout());
                    card.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(accentGreen),
                            new EmptyBorder(10, 15, 10, 15)
                    ));
                    card.setBackground(cardColor);
                    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
                    card.setPreferredSize(new Dimension(420, 60));

                    JLabel label = new JLabel("User ID: " + f.getReceiverId());
                    label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                    label.setForeground(textColor);

                    JButton sendBtn = new JButton("Send Request");
                    sendBtn.setBackground(accentGreen);
                    sendBtn.setForeground(Color.WHITE);
                    sendBtn.setFocusPainted(false);
                    sendBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
                    sendBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
                    sendBtn.setOpaque(true);
                    sendBtn.setBorderPainted(false);
                    sendBtn.setPreferredSize(new Dimension(130, 35));

                    sendBtn.addActionListener(e -> {
                        try (Connection freshConn = DBConnection.getConnection()) {
                            FriendDAO.sendFriendRequest(userId, f.getReceiverId(), freshConn);
                            dispose();
                            new PeopleYouMayKnowFrame(); // Reload
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    });

                    card.add(label, BorderLayout.WEST);
                    card.add(sendBtn, BorderLayout.EAST);
                    card.setAlignmentX(Component.LEFT_ALIGNMENT);

                    mainPanel.add(card);
                    mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JLabel error = new JLabel("Error loading suggestions.");
            error.setForeground(Color.RED);
            error.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(error);
        }

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(bgColor);

        add(scrollPane);
        setVisible(true);
    }
}
