package gui;

import dao.UserDAO;
import model.User;
import db.DBConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;

public class RegisterFrame extends JFrame {
    public RegisterFrame() {
        setTitle("LoopLink - Register");
        setSize(460, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Colors
        Color bgColor = new Color(30, 30, 46);
        Color inputBg = new Color(42, 42, 62);
        Color accent = new Color(40, 167, 69);
        Color textColor = Color.WHITE;
        Color linkColor = new Color(0, 153, 255);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(bgColor);
        panel.setBorder(new EmptyBorder(30, 50, 30, 50));

        JLabel heading = new JLabel("Create New Account");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 24));
        heading.setForeground(textColor);
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(heading);
        panel.add(Box.createRigidArea(new Dimension(0, 25)));

        JTextField nameField = new JTextField();
        styleTextField(nameField, "Full Name", inputBg, textColor, accent);

        JTextField emailField = new JTextField();
        styleTextField(emailField, "Email", inputBg, textColor, accent);

        JPasswordField passField = new JPasswordField();
        stylePasswordField(passField, "Password", inputBg, textColor, accent);

        JButton registerBtn = new JButton("Register");
        registerBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        registerBtn.setBackground(accent);
        registerBtn.setForeground(Color.WHITE);
        registerBtn.setFocusPainted(false);
        registerBtn.setContentAreaFilled(true);  // No hover effect
        registerBtn.setBorderPainted(false);     // Clean border
        registerBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        registerBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        registerBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String password = String.valueOf(passField.getPassword());

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try (Connection conn = DBConnection.getConnection()) {
                User newUser = new User(name, email, password);
                boolean success = UserDAO.register(newUser, conn);

                if (success) {
                    JOptionPane.showMessageDialog(this, "Account created successfully!");
                    dispose();
                    new LoginFrame();
                } else {
                    JOptionPane.showMessageDialog(this, "Email already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Registration failed!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton backToLogin = new JButton("← Back to Login");
        backToLogin.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        backToLogin.setForeground(linkColor);
        backToLogin.setBackground(bgColor);
        backToLogin.setBorderPainted(false);
        backToLogin.setFocusPainted(false);
        backToLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backToLogin.setAlignmentX(Component.CENTER_ALIGNMENT);

        backToLogin.addActionListener(e -> {
            dispose();
            new LoginFrame();
        });

        panel.add(nameField);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(emailField);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(passField);
        panel.add(Box.createRigidArea(new Dimension(0, 30)));
        panel.add(registerBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(backToLogin);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(bgColor);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        setContentPane(scrollPane);
        setVisible(true);
    }

    private void styleTextField(JTextField field, String title, Color bg, Color fg, Color border) {
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBackground(bg);
        field.setForeground(fg);
        field.setCaretColor(fg);
        field.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(border), title, 0, 0, null, fg));
    }

    private void stylePasswordField(JPasswordField field, String title, Color bg, Color fg, Color border) {
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBackground(bg);
        field.setForeground(fg);
        field.setCaretColor(fg);
        field.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(border), title, 0, 0, null, fg));
    }
}
