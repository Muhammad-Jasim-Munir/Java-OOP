package gui;

import dao.PostDAO;
import model.Post;
import model.User;
import util.Session;
import db.DBConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.util.List;

public class ProfileFrame extends JFrame {
    public ProfileFrame() {
        setTitle("LoopLink - Your Profile");
        setSize(600, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Theme Colors
        Color bgColor = new Color(30, 30, 46);
        Color cardColor = new Color(42, 42, 62);
        Color textColor = Color.WHITE;
        Color subTextColor = new Color(160, 160, 160);
        Color accent = new Color(0, 153, 255);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(bgColor);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        User user = Session.getCurrentUser();

        JLabel nameLabel = new JLabel(user.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        nameLabel.setForeground(textColor);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel emailLabel = new JLabel(user.getEmail());
        emailLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        emailLabel.setForeground(subTextColor);
        emailLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(nameLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(emailLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JLabel postHeading = new JLabel("Your Posts");
        postHeading.setFont(new Font("Segoe UI", Font.BOLD, 18));
        postHeading.setForeground(textColor);
        postHeading.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(postHeading);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        try (Connection conn = DBConnection.getConnection()) {
            List<Post> posts = PostDAO.getPostsByUser(user.getId(), conn);

            if (posts.isEmpty()) {
                JLabel noPosts = new JLabel("You haven’t posted anything yet.");
                noPosts.setFont(new Font("Segoe UI", Font.ITALIC, 14));
                noPosts.setForeground(subTextColor);
                noPosts.setAlignmentX(Component.CENTER_ALIGNMENT);
                panel.add(noPosts);
            } else {
                for (Post post : posts) {
                    JPanel postPanel = new JPanel();
                    postPanel.setLayout(new BorderLayout());
                    postPanel.setBackground(cardColor);
                    postPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
                    postPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));

                    JLabel postContent = new JLabel("<html>" + post.getContent() + "</html>");
                    postContent.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                    postContent.setForeground(textColor);
                    postPanel.add(postContent, BorderLayout.CENTER);

                    panel.add(postPanel);
                    panel.add(Box.createRigidArea(new Dimension(0, 10)));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JLabel error = new JLabel("Failed to load your posts.");
            error.setForeground(Color.RED);
            error.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(error);
        }

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(bgColor);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        setContentPane(scrollPane);

        setVisible(true);
    }
}
