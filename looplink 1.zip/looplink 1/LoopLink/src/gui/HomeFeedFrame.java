package gui;

import model.Post;
import util.Session;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Arrays;
import java.util.List;

public class HomeFeedFrame extends JFrame {
    public HomeFeedFrame() {
        setTitle("LoopLink - Home Feed");
        setSize(700, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Theme colors
        Color bgColor = new Color(30, 30, 46);
        Color cardColor = new Color(42, 42, 62);
        Color textColor = Color.WHITE;
        Color accent = new Color(0, 153, 255);
        Color green = new Color(40, 167, 69);
        Color red = new Color(220, 53, 69);

        // Realistic dummy posts
        List<Post> posts = Arrays.asList(
                new Post(1, "📸 Just came back from the mountains. Nature is magical! #travel #peace"),
                new Post(2, "👨‍💻 Started working on a new Java project today. Feeling productive."),
                new Post(3, "🎶 Listening to some Lo-Fi while studying. It helps me concentrate so much!"),
                new Post(4, "🔥 Who else watched the new season of 'Stranger Things'? Absolute madness!"),
                new Post(5, "🍕 Late-night cravings got me again. Ordered a pepperoni pizza 🍕😋")
        );

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(bgColor);
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Top nav buttons
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        navPanel.setBackground(bgColor);

        JButton createPostBtn = styledButton("Create Post", accent);
        createPostBtn.addActionListener(e -> new CreatePostFrame());

        JButton friendRequestsBtn = styledButton("Friend Requests", accent);
        friendRequestsBtn.addActionListener(e -> new FriendRequestFrame());

        JButton suggestionsBtn = styledButton("Suggestions", accent);
        suggestionsBtn.addActionListener(e -> new PeopleYouMayKnowFrame());

        JButton profileBtn = styledButton("Profile", accent);
        profileBtn.addActionListener(e -> new ProfileFrame());

        JButton logoutBtn = styledButton("Logout", red);
        logoutBtn.addActionListener(e -> {
            Session.clear();
            dispose();
            new LoginFrame();
        });

        navPanel.add(createPostBtn);
        navPanel.add(friendRequestsBtn);
        navPanel.add(suggestionsBtn);
        navPanel.add(profileBtn);
        navPanel.add(logoutBtn);
        mainPanel.add(navPanel);

        // Heading
        JLabel heading = new JLabel("Home Feed");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 22));
        heading.setForeground(textColor);
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(heading);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Display posts
        for (Post post : posts) {
            JPanel postPanel = new JPanel();
            postPanel.setLayout(new BoxLayout(postPanel, BoxLayout.Y_AXIS));
            postPanel.setBackground(cardColor);
            postPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            postPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150));

            JLabel content = new JLabel("<html>" + post.getContent() + "</html>");
            content.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            content.setForeground(textColor);
            postPanel.add(content);
            postPanel.add(Box.createRigidArea(new Dimension(0, 8)));

            // Like button
            JButton likeBtn = styledButton("Like", accent);
            likeBtn.addActionListener(e -> JOptionPane.showMessageDialog(this, "You liked the post!"));

            // Comment button with popup
            JButton commentBtn = styledButton("Comment", green);
            commentBtn.addActionListener(e -> {
                String comment = JOptionPane.showInputDialog(this, "Write your comment:");
                if (comment != null && !comment.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Comment added:\n" + comment);
                }
            });

            JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            actionPanel.setBackground(cardColor);
            actionPanel.add(likeBtn);
            actionPanel.add(commentBtn);

            postPanel.add(actionPanel);

            mainPanel.add(Box.createRigidArea(new Dimension(0, 12)));
            mainPanel.add(postPanel);
        }

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(bgColor);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        setContentPane(scrollPane);

        setVisible(true);
    }

    private JButton styledButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(true);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(120, 30));
        return btn;
    }
}
