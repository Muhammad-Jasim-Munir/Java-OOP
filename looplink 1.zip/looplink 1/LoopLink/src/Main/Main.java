import gui.LoginFrame;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Optional: set system look and feel for native GUI appearance
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        // Launch the LoginFrame
        SwingUtilities.invokeLater(() -> new LoginFrame());
    }
}
