package util;

import model.User;

public class Session {
    private static User currentUser = null;

    // Set the logged-in user
    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    // Get the logged-in user
    public static User getCurrentUser() {
        return currentUser;
    }

    // Clear the session (logout)
    public static void clear() {
        currentUser = null;
    }

    // Check if user is logged in
    public static boolean isLoggedIn() {
        return currentUser != null;
    }
}
