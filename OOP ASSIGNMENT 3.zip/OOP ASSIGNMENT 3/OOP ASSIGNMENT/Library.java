import java.io.*;
import java.util.*;

public class Library {
    private List<Book> books = new ArrayList<>();

    public void addBook(Book book) throws Exception {
        for (Book b : books) {
            if (b.getIsbn().equals(book.getIsbn())) {
                throw new Exception("Duplicate ISBN!");
            }
        }
        books.add(book);
    }

    public void removeBook(String isbn) throws Exception {
        Book toRemove = findBookByISBN(isbn);
        if (toRemove == null) throw new Exception("Book not found!");
        books.remove(toRemove);
    }

    public List<Book> getAllBooks() {
        return books;
    }

    public Book findBookByISBN(String isbn) {
        for (Book b : books) {
            if (b.getIsbn().equals(isbn)) return b;
        }
        return null;
    }

    public void saveToFile(String filename) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(filename))) {
            for (Book b : books) {
                out.println(b.toString());
            }
        }
    }

    public void loadFromFile(String filename) throws IOException {
        books.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                books.add(Book.fromString(line));
            }
        }
    }
}
