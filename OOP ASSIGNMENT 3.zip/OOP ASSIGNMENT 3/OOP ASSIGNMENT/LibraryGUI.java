import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class LibraryGUI extends JFrame {
    Library library = new Library();
    DefaultTableModel model = new DefaultTableModel(new String[]{"Title", "Author", "Year", "ISBN"}, 0);

    JTextField txtTitle = new JTextField(10);
    JTextField txtAuthor = new JTextField(10);
    JTextField txtYear = new JTextField(5);
    JTextField txtISBN = new JTextField(10);
    JTextField txtSearch = new JTextField(10);

    public LibraryGUI() {
        setTitle("Personal Library Manager");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 500);
        setLayout(new BorderLayout());

        // Top Panel - Form
        JPanel formPanel = new JPanel(new GridLayout(2, 4));
        formPanel.add(new JLabel("Title:")); formPanel.add(txtTitle);
        formPanel.add(new JLabel("Author:")); formPanel.add(txtAuthor);
        formPanel.add(new JLabel("Year:")); formPanel.add(txtYear);
        formPanel.add(new JLabel("ISBN:")); formPanel.add(txtISBN);
        add(formPanel, BorderLayout.NORTH);

        // Center - Table
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom - Buttons
        JPanel buttonPanel = new JPanel();

        JButton btnAdd = new JButton("Add Book");
        JButton btnRemove = new JButton("Remove Book");
        JButton btnSave = new JButton("Save to File");
        JButton btnLoad = new JButton("Load from File");
        JButton btnSearch = new JButton("Search Book");

        buttonPanel.add(btnAdd); buttonPanel.add(btnRemove);
        buttonPanel.add(btnSave); buttonPanel.add(btnLoad);

        buttonPanel.add(new JLabel("Search ISBN:")); buttonPanel.add(txtSearch); buttonPanel.add(btnSearch);

        add(buttonPanel, BorderLayout.SOUTH);

        // Button Listeners
        btnAdd.addActionListener(e -> {
            try {
                int year = Integer.parseInt(txtYear.getText());
                Book book = new Book(txtTitle.getText(), txtAuthor.getText(), year, txtISBN.getText());
                library.addBook(book);
                model.addRow(new String[]{book.getTitle(), book.getAuthor(), String.valueOf(book.getYear()), book.getIsbn()});
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid year.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        btnRemove.addActionListener(e -> {
            try {
                String isbn = txtISBN.getText();
                library.removeBook(isbn);
                refreshTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        btnSave.addActionListener(e -> {
            try {
                library.saveToFile("library.txt");
                JOptionPane.showMessageDialog(this, "Saved successfully.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving file.");
            }
        });

        btnLoad.addActionListener(e -> {
            try {
                library.loadFromFile("library.txt");
                refreshTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error loading file.");
            }
        });

        btnSearch.addActionListener(e -> {
            Book book = library.findBookByISBN(txtSearch.getText());
            if (book != null) {
                JOptionPane.showMessageDialog(this, book.getTitle() + " by " + book.getAuthor());
            } else {
                JOptionPane.showMessageDialog(this, "Book not found.");
            }
        });

        setVisible(true);
    }

    void refreshTable() {
        model.setRowCount(0);
        for (Book b : library.getAllBooks()) {
            model.addRow(new String[]{b.getTitle(), b.getAuthor(), String.valueOf(b.getYear()), b.getIsbn()});
        }
    }

    public static void main(String[] args) {
        new LibraryGUI();
    }
}
