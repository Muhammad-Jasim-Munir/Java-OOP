# 📘 LoopLink — A Java-Based Facebook Clone

LoopLink is a lightweight social media desktop application built in **Java (Swing GUI + OOP)** with **MySQL/XAMPP backend**, modeled after Facebook.

---

## 🚀 Features

✅ User Registration & Login  
✅ Session Management  
✅ Post Creation with Image Support  
✅ Scrollable Home Feed  
✅ Profile Page with User Posts  
✅ Comment System  
✅ Like/Unlike on Posts  
✅ Clean, Component-Based Architecture (OOP)  

---

## 🧱 Project Structure

