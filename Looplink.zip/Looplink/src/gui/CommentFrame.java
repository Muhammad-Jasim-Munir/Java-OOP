// File: gui/CommentFrame.java
package gui;

import dao.CommentDAO;
import model.Comment;
import model.User;
import util.Session;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class CommentFrame extends JFrame {

    private JTextArea commentInput;
    private JTextArea commentDisplay;
    private JButton postCommentButton;

    private int postId;

    public CommentFrame(int postId) {
        this.postId = postId;

        setTitle("Comments");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel titleLabel = new JLabel("Comments on this Post:");
        titleLabel.setBounds(20, 10, 400, 25);
        panel.add(titleLabel);

        commentDisplay = new JTextArea();
        commentDisplay.setEditable(false);
        commentDisplay.setLineWrap(true);
        commentDisplay.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(commentDisplay);
        scrollPane.setBounds(20, 40, 440, 200);
        panel.add(scrollPane);

        commentInput = new JTextArea();
        commentInput.setBounds(20, 250, 440, 50);
        commentInput.setLineWrap(true);
        commentInput.setWrapStyleWord(true);
        panel.add(commentInput);

        postCommentButton = new JButton("Post Comment");
        postCommentButton.setBounds(180, 310, 140, 30);
        panel.add(postCommentButton);

        postCommentButton.addActionListener((ActionEvent e) -> postComment());

        loadComments();
    }

    private void postComment() {
        String content = commentInput.getText().trim();
        if (content.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Comment cannot be empty.");
            return;
        }

        User user = Session.getCurrentUser();
        Comment comment = new Comment(user.getId(), postId, content);
        boolean success = CommentDAO.saveComment(comment);

        if (success) {
            commentInput.setText("");
            loadComments();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to post comment.");
        }
    }

    private void loadComments() {
        List<Comment> comments = CommentDAO.getCommentsByPostId(postId);
        StringBuilder sb = new StringBuilder();

        for (Comment c : comments) {
            sb.append("👤 User ID ").append(c.getUserId()).append(": ")
              .append(c.getContent()).append("\n🕒 ").append(c.getTimestamp()).append("\n\n");
        }

        commentDisplay.setText(sb.toString());
    }
}
