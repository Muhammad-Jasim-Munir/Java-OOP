package gui;

import dao.UserDAO;
import model.User;
import util.Session;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JCheckBox showPassword;

    public LoginFrame() {
        setTitle("Login - LoopLink");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Logo (optional)
        JLabel logo = new JLabel("🔁 LoopLink");
        logo.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(logo, gbc);

        // Email
        gbc.gridy++;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(20);
        panel.add(emailField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        panel.add(passwordField, gbc);

        // Show password
        gbc.gridy++;
        gbc.gridx = 1;
        showPassword = new JCheckBox("Show Password");
        showPassword.setBackground(Color.WHITE);
        showPassword.addActionListener(e -> {
            passwordField.setEchoChar(showPassword.isSelected() ? (char) 0 : '•');
        });
        panel.add(showPassword, gbc);

        // Login Button
        gbc.gridy++;
        JButton loginBtn = new JButton("Login");
        panel.add(loginBtn, gbc);

        // Register Button
        gbc.gridy++;
        JButton registerBtn = new JButton("Create Account");
        panel.add(registerBtn, gbc);

        add(panel);
        setVisible(true);

        // Action Listeners
        loginBtn.addActionListener(e -> handleLogin());
        registerBtn.addActionListener(e -> {
            dispose();
            new RegisterFrame();
        });
    }

    private void handleLogin() {
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both email and password.");
            return;
        }

        User user = UserDAO.login(email, password);
        if (user != null) {
            Session.setCurrentUser(user);
            JOptionPane.showMessageDialog(this, "Login successful! Welcome " + user.getName());
            dispose();
            new HomeFeedFrame(); // open the main feed
        } else {
            JOptionPane.showMessageDialog(this, "Invalid email or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
}
