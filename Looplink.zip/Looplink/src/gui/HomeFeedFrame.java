// File: gui/HomeFeedFrame.java
package gui;

import dao.LikeDAO;
import dao.PostDAO;
import model.Post;
import model.User;
import util.Session;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class HomeFeedFrame extends JFrame {

    private JPanel postPanel;

    public HomeFeedFrame() {
        setTitle("LoopLink - Home Feed");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        User user = Session.getCurrentUser();

        // Top bar
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton createPostButton = new JButton("Create Post");
        JButton profileButton = new JButton("My Profile");
        JButton logoutButton = new JButton("Logout");

        topPanel.add(createPostButton);
        topPanel.add(profileButton);
        topPanel.add(logoutButton);
        add(topPanel, BorderLayout.NORTH);

        // Post feed panel
        postPanel = new JPanel();
        postPanel.setLayout(new BoxLayout(postPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(postPanel);
        add(scrollPane, BorderLayout.CENTER);

        // Load posts
        loadPosts();

        // Button actions
        createPostButton.addActionListener(e -> new CreatePostFrame().setVisible(true));
        profileButton.addActionListener(e -> new ProfileFrame().setVisible(true));
        logoutButton.addActionListener(e -> {
            Session.clearSession();
            dispose();
            new LoginFrame().setVisible(true);
        });
    }

    private void loadPosts() {
        postPanel.removeAll();

        List<Post> posts = PostDAO.getAllPosts();
        User currentUser = Session.getCurrentUser();

        for (Post post : posts) {
            JPanel card = new JPanel();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            card.setBackground(Color.WHITE);
            card.setAlignmentX(Component.LEFT_ALIGNMENT);
            card.setMaximumSize(new Dimension(500, 200));
            card.setPreferredSize(new Dimension(500, 150));

            JLabel contentLabel = new JLabel("<html><b>Post:</b> " + post.getContent() + "</html>");
            contentLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            card.add(contentLabel);

            JLabel timeLabel = new JLabel("🕒 " + post.getTimestamp().toString());
            timeLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            card.add(timeLabel);

            int likeCount = LikeDAO.countLikes(post.getId());
            boolean isLiked = LikeDAO.isPostLikedByUser(currentUser.getId(), post.getId());

            JButton likeBtn = new JButton(isLiked ? "❤️ Unlike (" + likeCount + ")" : "🤍 Like (" + likeCount + ")");
            JButton commentBtn = new JButton("💬 Comments");

            likeBtn.addActionListener(e -> {
                if (isLiked) {
                    LikeDAO.removeLike(currentUser.getId(), post.getId());
                } else {
                    LikeDAO.addLike(new model.Like(currentUser.getId(), post.getId()));
                }
                loadPosts(); // reload feed
            });

            commentBtn.addActionListener(e -> {
                new CommentFrame(post.getId()).setVisible(true);
            });

            JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            actionPanel.add(likeBtn);
            actionPanel.add(commentBtn);
            card.add(actionPanel);

            postPanel.add(Box.createVerticalStrut(10));
            postPanel.add(card);
        }

        postPanel.revalidate();
        postPanel.repaint();
    }
}
