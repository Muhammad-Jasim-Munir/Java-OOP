// File: gui/CreatePostFrame.java
package gui;

import dao.PostDAO;
import model.Post;
import util.Session;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreatePostFrame extends JFrame {

    private JTextArea contentArea;
    private JTextField imagePathField;
    private JButton submitButton, cancelButton;

    public CreatePostFrame() {
        setTitle("Create a New Post");
        setSize(500, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel contentLabel = new JLabel("Write your post:");
        contentLabel.setBounds(30, 20, 200, 25);
        panel.add(contentLabel);

        contentArea = new JTextArea();
        contentArea.setBounds(30, 50, 420, 100);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        panel.add(contentArea);

        JLabel imageLabel = new JLabel("Image path (optional):");
        imageLabel.setBounds(30, 160, 200, 25);
        panel.add(imageLabel);

        imagePathField = new JTextField();
        imagePathField.setBounds(30, 190, 420, 25);
        panel.add(imagePathField);

        submitButton = new JButton("Post");
        submitButton.setBounds(100, 240, 120, 35);
        panel.add(submitButton);

        cancelButton = new JButton("Cancel");
        cancelButton.setBounds(260, 240, 120, 35);
        panel.add(cancelButton);

        // Button actions
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createPost();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the window
            }
        });
    }

    private void createPost() {
        String content = contentArea.getText().trim();
        String imagePath = imagePathField.getText().trim();
        int userId = Session.getCurrentUser().getId();

        if (content.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Post content cannot be empty.");
            return;
        }

        Post post = new Post(userId, content, imagePath);
        boolean success = PostDAO.savePost(post);

        if (success) {
            JOptionPane.showMessageDialog(this, "Post created successfully!");
            dispose(); // Close the frame
        } else {
            JOptionPane.showMessageDialog(this, "Failed to create post. Try again.");
        }
    }
}
