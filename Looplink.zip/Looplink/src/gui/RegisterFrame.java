// File: gui/RegisterFrame.java
package gui;

import dao.UserDAO;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegisterFrame extends JFrame {

    private JTextField nameField, emailField;
    private JPasswordField passwordField;
    private JTextArea bioField;
    private JButton registerButton, backToLoginButton;

    public RegisterFrame() {
        setTitle("LoopLink - Register");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel titleLabel = new JLabel("Create Your LoopLink Account", JLabel.CENTER);
        titleLabel.setBounds(50, 20, 350, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(titleLabel);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 70, 100, 25);
        panel.add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(150, 70, 220, 25);
        panel.add(nameField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 110, 100, 25);
        panel.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(150, 110, 220, 25);
        panel.add(emailField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 150, 100, 25);
        panel.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 150, 220, 25);
        panel.add(passwordField);

        JLabel bioLabel = new JLabel("Bio:");
        bioLabel.setBounds(50, 190, 100, 25);
        panel.add(bioLabel);

        bioField = new JTextArea();
        bioField.setBounds(150, 190, 220, 60);
        bioField.setLineWrap(true);
        bioField.setWrapStyleWord(true);
        panel.add(bioField);

        registerButton = new JButton("Register");
        registerButton.setBounds(50, 270, 140, 35);
        panel.add(registerButton);

        backToLoginButton = new JButton("Back to Login");
        backToLoginButton.setBounds(230, 270, 140, 35);
        panel.add(backToLoginButton);

        // Button actions
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });

        backToLoginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame().setVisible(true);
            }
        });
    }

    private void register() {
        String name = nameField.getText();
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        String bio = bioField.getText();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all required fields.");
            return;
        }

        User user = new User(name, email, password, bio);
        boolean success = UserDAO.registerUser(user);

        if (success) {
            JOptionPane.showMessageDialog(this, "Registration successful. Please login.");
            dispose();
            new LoginFrame().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Registration failed. Try again.");
        }
    }
}
