// File: gui/ProfileFrame.java
package gui;

import dao.PostDAO;
import java.util.List;
import javax.swing.*;
import model.Post;
import model.User;
import util.Session;

public class ProfileFrame extends JFrame {

    private JLabel nameLabel, emailLabel, bioLabel;
    private JTextArea postListArea;

    public ProfileFrame() {
        setTitle("My Profile - LoopLink");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        User user = Session.getCurrentUser();

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        nameLabel = new JLabel("Name: " + user.getName());
        nameLabel.setBounds(30, 20, 400, 25);
        panel.add(nameLabel);

        emailLabel = new JLabel("Email: " + user.getEmail());
        emailLabel.setBounds(30, 50, 400, 25);
        panel.add(emailLabel);

        bioLabel = new JLabel("Bio: " + user.getBio());
        bioLabel.setBounds(30, 80, 400, 25);
        panel.add(bioLabel);

        JLabel postsLabel = new JLabel("My Posts:");
        postsLabel.setBounds(30, 120, 200, 25);
        panel.add(postsLabel);

        postListArea = new JTextArea();
        postListArea.setEditable(false);
        postListArea.setLineWrap(true);
        postListArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(postListArea);
        scrollPane.setBounds(30, 150, 420, 280);
        panel.add(scrollPane);

        // Load user posts
        loadPosts(user.getId());
    }

    private void loadPosts(int userId) {
        List<Post> posts = PostDAO.getPostsByUser(userId);
        StringBuilder sb = new StringBuilder();

        for (Post post : posts) {
            sb.append("➤ ").append(post.getContent()).append("\n");
            if (post.getImagePath() != null && !post.getImagePath().isEmpty()) {
                sb.append("📷 Image: ").append(post.getImagePath()).append("\n");
            }
            sb.append("🕒 ").append(post.getTimestamp()).append("\n\n");
        }

        postListArea.setText(sb.toString());
    }
}
