package Main.Main.java;// File: Main.java
import gui.LoginFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Set a nice look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Launch the login screen
        SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}
