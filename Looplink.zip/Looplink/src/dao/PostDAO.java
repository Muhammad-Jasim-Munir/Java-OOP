// File: dao/PostDAO.java
package dao;

import db.DBConnection;
import model.Post;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PostDAO {

    // Save a new post
    public static boolean savePost(Post post) {
        String sql = "INSERT INTO posts (user_id, content, image_path, timestamp) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, post.getUserId());
            stmt.setString(2, post.getContent());
            stmt.setString(3, post.getImagePath());
            stmt.setTimestamp(4, Timestamp.valueOf(post.getTimestamp()));

            int rows = stmt.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get all posts (newest first)
    public static List<Post> getAllPosts() {
        List<Post> posts = new ArrayList<>();
        String sql = "SELECT * FROM posts ORDER BY timestamp DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("timestamp");
                LocalDateTime dateTime = ts != null ? ts.toLocalDateTime() : null;
                Post post = new Post(
                    rs.getInt("id"),
                    rs.getInt("user_id"),
                    rs.getString("content"),
                    rs.getString("image_path"),
                    dateTime
                );
                posts.add(post);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return posts;
    }

    // Optional: Get posts by specific user
    public static List<Post> getPostsByUser(int userId) {
        List<Post> posts = new ArrayList<>();
        String sql = "SELECT * FROM posts WHERE user_id = ? ORDER BY timestamp DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Post post = new Post(
                    rs.getInt("id"),
                    rs.getInt("user_id"),
                    rs.getString("content"),
                    rs.getString("image_path"),
                    rs.getTimestamp("timestamp").toLocalDateTime()
                );
                posts.add(post);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return posts;
    }
}
