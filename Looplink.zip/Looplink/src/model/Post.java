// File: model/Post.java
package model;

import java.time.LocalDateTime;

public class Post {
    private int id;
    private int userId;
    private String content;
    private String imagePath;
    private LocalDateTime timestamp;

    // Constructor for new post (no ID, timestamp generated)
    public Post(int userId, String content, String imagePath) {
        this.userId = userId;
        this.content = content;
        this.imagePath = imagePath;
        this.timestamp = LocalDateTime.now();
    }

    // Constructor for DB-fetched post
    public Post(int id, int userId, String content, String imagePath, LocalDateTime timestamp) {
        this.id = id;
        this.userId = userId;
        this.content = content;
        this.imagePath = imagePath;
        this.timestamp = timestamp;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    @Override
    public String toString() {
        return "Post{" +
                "id=" + id +
                ", userId=" + userId +
                ", content='" + content + '\'' +
                ", imagePath='" + imagePath + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
