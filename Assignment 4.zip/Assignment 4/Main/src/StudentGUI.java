import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.SQLException;

public class StudentGUI {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private JTextField nameField, rollField, deptField, emailField, idField;
    private JButton addBtn, updateBtn, deleteBtn;

    public StudentGUI() {
        frame = new JFrame("Student Management System");
        frame.setSize(750, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel idLabel = new JLabel("ID:");
        idLabel.setBounds(30, 20, 100, 25);
        frame.add(idLabel);
        idField = new JTextField();
        idField.setBounds(150, 20, 150, 25);
        frame.add(idField);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(30, 60, 100, 25);
        frame.add(nameLabel);
        nameField = new JTextField();
        nameField.setBounds(150, 60, 150, 25);
        frame.add(nameField);

        JLabel rollLabel = new JLabel("Roll No:");
        rollLabel.setBounds(30, 100, 100, 25);
        frame.add(rollLabel);
        rollField = new JTextField();
        rollField.setBounds(150, 100, 150, 25);
        frame.add(rollField);

        JLabel deptLabel = new JLabel("Department:");
        deptLabel.setBounds(30, 140, 100, 25);
        frame.add(deptLabel);
        deptField = new JTextField();
        deptField.setBounds(150, 140, 150, 25);
        frame.add(deptField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(30, 180, 100, 25);
        frame.add(emailLabel);
        emailField = new JTextField();
        emailField.setBounds(150, 180, 150, 25);
        frame.add(emailField);

        // Buttons
        addBtn = new JButton("Add");
        addBtn.setBounds(330, 20, 100, 25);
        frame.add(addBtn);

        updateBtn = new JButton("Update");
        updateBtn.setBounds(330, 60, 100, 25);
        frame.add(updateBtn);

        deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(330, 100, 100, 25);
        frame.add(deleteBtn);

        // Table
        model = new DefaultTableModel(new String[]{"ID", "Name", "Roll No", "Department", "Email"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(30, 230, 680, 200);
        frame.add(scrollPane);

        loadStudents();

        addBtn.addActionListener(e -> addStudent());
        updateBtn.addActionListener(e -> updateStudent());
        deleteBtn.addActionListener(e -> deleteStudent());

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                idField.setText(model.getValueAt(row, 0).toString());
                nameField.setText(model.getValueAt(row, 1).toString());
                rollField.setText(model.getValueAt(row, 2).toString());
                deptField.setText(model.getValueAt(row, 3).toString());
                emailField.setText(model.getValueAt(row, 4).toString());
            }
        });

        frame.setVisible(true);
    }

    private void loadStudents() {
        try {
            model.setRowCount(0);
            for (Student s : StudentDAO.getAllStudents()) {
                model.addRow(new Object[]{s.getId(), s.getName(), s.getRollNumber(), s.getDepartment(), s.getEmail()});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error loading students: " + e.getMessage());
        }
    }

    private void addStudent() {
        try {
            Student s = new Student(0, nameField.getText(), rollField.getText(), deptField.getText(), emailField.getText());
            StudentDAO.insertStudent(s);
            loadStudents();
            clearFields();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error adding student: " + e.getMessage());
        }
    }

    private void updateStudent() {
        try {
            int id = Integer.parseInt(idField.getText());
            Student s = new Student(id, nameField.getText(), rollField.getText(), deptField.getText(), emailField.getText());
            StudentDAO.updateStudent(s);
            loadStudents();
            clearFields();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error updating student: " + e.getMessage());
        }
    }

    private void deleteStudent() {
        try {
            int id = Integer.parseInt(idField.getText());
            StudentDAO.deleteStudent(id);
            loadStudents();
            clearFields();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error deleting student: " + e.getMessage());
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        rollField.setText("");
        deptField.setText("");
        emailField.setText("");
    }

    public static void main(String[] args) {
        new StudentGUI();
    }
}