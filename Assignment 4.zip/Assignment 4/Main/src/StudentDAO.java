import java.sql.*;
import java.util.ArrayList;

public class StudentDAO {
    public static void insertStudent(Student student) throws SQLException {
        String sql = "INSERT INTO students (name, roll_number, department, email) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getRollNumber());
            stmt.setString(3, student.getDepartment());
            stmt.setString(4, student.getEmail());
            stmt.executeUpdate();
        }
    }

    public static void updateStudent(Student student) throws SQLException {
        String sql = "UPDATE students SET name=?, roll_number=?, department=?, email=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getRollNumber());
            stmt.setString(3, student.getDepartment());
            stmt.setString(4, student.getEmail());
            stmt.setInt(5, student.getId());
            stmt.executeUpdate();
        }
    }

    public static void deleteStudent(int id) throws SQLException {
        String sql = "DELETE FROM students WHERE id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public static ArrayList<Student> getAllStudents() throws SQLException {
        ArrayList<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM students";
        try (Connection conn = DBConnection.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("roll_number"),
                        rs.getString("department"),
                        rs.getString("email")
                ));
            }
        }
        return list;
    }
}