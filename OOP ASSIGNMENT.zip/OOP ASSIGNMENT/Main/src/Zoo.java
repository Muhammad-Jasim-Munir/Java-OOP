import java.util.ArrayList;

public class Zoo {
    public static void main(String[] args) {
        ArrayList<Animal> animals = new ArrayList<>();

        animals.add(new Lion("Leo", 5));
        animals.add(new Parrot("Polly", 2));
        animals.add(new Shark("Finn", 3));
        animals.add(new Duck("Daffy", 4));

        for (Animal animal : animals) {
            animal.displayInfo();
            animal.makeSound();
            animal.eat();

            if (animal instanceof Flyable) {
                ((Flyable) animal).fly();
            }

            if (animal instanceof Swimmable) {
                ((Swimmable) animal).swim();
            }

            System.out.println();
        }
    }
}