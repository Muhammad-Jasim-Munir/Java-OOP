public class Lion extends Animal {
    public Lion(String name, int age) {
        super(name, age);
    }

    public void makeSound() {
        System.out.println("Sound: Roar!");
    }

    public void eat() {
        System.out.println(name + " is eating meat.");
    }
}