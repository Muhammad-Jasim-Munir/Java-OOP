public class Parrot extends Animal implements Flyable {
    public Parrot(String name, int age) {
        super(name, age);
    }

    public void makeSound() {
        System.out.println("Sound: Squawk!");
    }

    public void eat() {
        System.out.println(name + " is eating seeds.");
    }

    public void fly() {
        System.out.println(name + " is flying.");
    }
}