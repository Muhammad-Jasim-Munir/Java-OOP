public class Duck extends Animal implements Flyable, Swimmable {
    public Duck(String name, int age) {
        super(name, age);
    }

    public void makeSound() {
        System.out.println("Sound: Quack!");
    }

    public void eat() {
        System.out.println(name + " is eating insects.");
    }

    public void fly() {
        System.out.println(name + " is flying.");
    }

    public void swim() {
        System.out.println(name + " is swimming.");
    }
}