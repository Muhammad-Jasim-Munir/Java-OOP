public class Shark extends Animal implements Swimmable {
    public Shark(String name, int age) {
        super(name, age);
    }

    public void makeSound() {
        System.out.println("Sound: (Silent)");
    }

    public void eat() {
        System.out.println(name + " is eating fish.");
    }

    public void swim() {
        System.out.println(name + " is swimming.");
    }
}